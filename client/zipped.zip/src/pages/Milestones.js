import React, { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";
import MilestoneSidebar from "../components/MilestoneSidebar";
import {
  fetchMilestoneCategories,
  fetchMilestoneLevels,
  fetchMilestoneProgress,
  fetchMilestoneChallenges,
  fetchMyMilestoneSubmissions,
  createMilestoneSubmission,
  updateMilestoneSubmission,
} from "../redux/thunks/milestonesThunks";
import {
  selectMilestoneCategories,
  selectMilestoneLevels,
  selectMilestoneChallenges,
  selectMyMilestoneSubmissions,
  selectMilestoneProgress,
  selectMilestonesLoading,
  selectMilestonesActionLoading,
} from "../redux/selectors/milestonesSelectors";

const Milestones = () => {
  const dispatch = useDispatch();
  const categories = useSelector(selectMilestoneCategories);
  const loading = useSelector(selectMilestonesLoading);
  const actionLoading = useSelector(selectMilestonesActionLoading);
  const [activeCategoryId, setActiveCategoryId] = useState("");
  const [activeLevelId, setActiveLevelId] = useState("");
  const [activeChallengeId, setActiveChallengeId] = useState("");
  const [repoUrl, setRepoUrl] = useState("");
  const [demoUrl, setDemoUrl] = useState("");
  const [notes, setNotes] = useState("");
  const [submitError, setSubmitError] = useState("");
  const [submitSuccess, setSubmitSuccess] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showChallenges, setShowChallenges] = useState(true);

  useEffect(() => {
    dispatch(fetchMilestoneCategories());
    dispatch(fetchMyMilestoneSubmissions());
  }, [dispatch]);

  useEffect(() => {
    if (categories.length && !activeCategoryId) {
      setActiveCategoryId(categories[0]._id);
    }
  }, [categories, activeCategoryId]);

  useEffect(() => {
    if (!activeCategoryId) return;
    dispatch(fetchMilestoneLevels(activeCategoryId));
    dispatch(fetchMilestoneProgress({ categoryId: activeCategoryId }));
    setActiveLevelId("");
    setActiveChallengeId("");
    setSubmitError("");
    setSubmitSuccess("");
  }, [dispatch, activeCategoryId]);

  const levels = useSelector((state) =>
    selectMilestoneLevels(state, activeCategoryId),
  );
  const progress = useSelector((state) =>
    selectMilestoneProgress(state, activeCategoryId),
  );
  const challenges = useSelector((state) =>
    selectMilestoneChallenges(state, activeLevelId),
  );
  const mySubmissions = useSelector(selectMyMilestoneSubmissions);

  const activeCategory = categories.find(
    (category) => category._id === activeCategoryId,
  );
  const activeLevel = levels.find((level) => level._id === activeLevelId);
  const activeChallenge = challenges.find(
    (challenge) => challenge._id === activeChallengeId,
  );

  const progressMap = useMemo(() => {
    return progress.reduce((acc, item) => {
      acc[item.levelId] = item.status;
      return acc;
    }, {});
  }, [progress]);

  const getStatusBadge = (status) => {
    if (status === "completed")
      return { className: "badge-success", text: "Completed" };
    if (status === "unlocked")
      return { className: "badge-info", text: "In Progress" };
    return { className: "badge-warning", text: "Not Started" };
  };

  useEffect(() => {
    if (!activeLevelId) return;
    dispatch(fetchMilestoneChallenges(activeLevelId));
  }, [dispatch, activeLevelId]);

  useEffect(() => {
    if (!levels.length) return;
    if (activeLevelId) return;
    if (levels[0]?._id) {
      setActiveLevelId(levels[0]._id);
    }
  }, [levels, activeLevelId]);

  useEffect(() => {
    if (!activeChallengeId) {
      setRepoUrl("");
      setDemoUrl("");
      setNotes("");
      return;
    }
    const existing = mySubmissions.find((submission) => {
      const challengeId = submission.challengeId?._id || submission.challengeId;
      return challengeId === activeChallengeId;
    });
    if (existing) {
      setRepoUrl(existing.repoUrl || "");
      setDemoUrl(existing.demoUrl || "");
      setNotes(existing.notes || "");
    } else {
      setRepoUrl("");
      setDemoUrl("");
      setNotes("");
    }
  }, [activeChallengeId, mySubmissions]);

  const handleSelectLevel = (levelId) => {
    setActiveLevelId(levelId);
    setActiveChallengeId("");
    setSubmitError("");
    setSubmitSuccess("");
    setShowChallenges(true);
  };

  const handleSelectChallenge = (challengeId) => {
    setActiveChallengeId(challengeId);
    setSubmitError("");
    setSubmitSuccess("");
    setShowChallenges(false);
  };

  const getSubmissionForChallenge = (challengeId) => {
    return mySubmissions.find((submission) => {
      const id = submission.challengeId?._id || submission.challengeId;
      return id === challengeId;
    });
  };

  const firstIncompleteIndex = useMemo(() => {
    for (let i = 0; i < challenges.length; i += 1) {
      const submission = getSubmissionForChallenge(challenges[i]._id);
      if (submission?.status !== "approved") {
        return i;
      }
    }
    return challenges.length;
  }, [challenges, mySubmissions]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitError("");
    setSubmitSuccess("");

    if (!activeChallengeId) return;
    const existing = getSubmissionForChallenge(activeChallengeId);

    try {
      if (existing) {
        await dispatch(
          updateMilestoneSubmission({
            id: existing._id,
            payload: { repoUrl, demoUrl, notes },
          }),
        ).unwrap();
        setSubmitSuccess("Submission updated.");
      } else {
        await dispatch(
          createMilestoneSubmission({
            challengeId: activeChallengeId,
            repoUrl,
            demoUrl,
            notes,
          }),
        ).unwrap();
        setSubmitSuccess("Submission created.");
      }
      dispatch(fetchMyMilestoneSubmissions());
    } catch (error) {
      setSubmitError(error || "Failed to submit");
    }
  };

  return (
    <>
      <Navbar />
      <div className="container mt-8">
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              className="btn btn-secondary lg:hidden"
              onClick={() => {
                setShowChallenges(true);
                setIsSidebarOpen(true);
              }}
            >
              Menu
            </button>
            <h1 className="text-2xl font-bold">Milestone Challenges</h1>
          </div>
          <Link to="/challenges" className="btn btn-outline">
            Weekly Challenges
          </Link>
        </div>

        {isSidebarOpen && (
          <div className="fixed inset-0 z-40 flex lg:hidden">
            <div
              className="absolute inset-0 bg-black/40"
              onClick={() => setIsSidebarOpen(false)}
            />
            <div className="relative w-72 h-full bg-white shadow-xl p-4 overflow-y-auto">
              <MilestoneSidebar
                categories={categories}
                activeCategoryId={activeCategoryId}
                onSelectCategory={(id) => {
                  setActiveCategoryId(id);
                  setShowChallenges(true);
                  setIsSidebarOpen(false);
                }}
                levels={levels}
                activeLevelId={activeLevelId}
                onSelectLevel={(id) => {
                  handleSelectLevel(id);
                  setIsSidebarOpen(false);
                }}
                levelProgressMap={progressMap}
                activeChallengeId={activeChallengeId}
                showChangeChallenge={!showChallenges && !!activeChallengeId}
                onChangeChallenge={() => {
                  setShowChallenges(true);
                  setIsSidebarOpen(false);
                }}
                loading={loading}
                onClose={() => setIsSidebarOpen(false)}
              />
            </div>
          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-6">
          <div className="w-full lg:w-72">
            <MilestoneSidebar
              categories={categories}
              activeCategoryId={activeCategoryId}
              onSelectCategory={(id) => {
                setActiveCategoryId(id);
                setShowChallenges(true);
              }}
              levels={levels}
              activeLevelId={activeLevelId}
              onSelectLevel={handleSelectLevel}
              levelProgressMap={progressMap}
              activeChallengeId={activeChallengeId}
              showChangeChallenge={!showChallenges && !!activeChallengeId}
              onChangeChallenge={() => setShowChallenges(true)}
              loading={loading}
            />
          </div>

          {showChallenges && (
            <div className="w-full lg:w-96">
              <div className="card">
                <h2 className="text-xl font-semibold mb-4">Challenges</h2>
                {!activeLevelId ? (
                  <p style={{ color: "var(--text-secondary)" }}>
                    Select a level to view challenges.
                  </p>
                ) : challenges.length === 0 ? (
                  <p style={{ color: "var(--text-secondary)" }}>
                    No challenges available for this level yet.
                  </p>
                ) : (
                  <div className="flex flex-col gap-2">
                    {challenges.map((challenge, index) => {
                      const submission = getSubmissionForChallenge(
                        challenge._id,
                      );
                      const status = submission?.status || "not submitted";
                      const isActive = activeChallengeId === challenge._id;
                      const isLocked = index > firstIncompleteIndex;
                      return (
                        <button
                          key={challenge._id}
                          type="button"
                          onClick={() => handleSelectChallenge(challenge._id)}
                          disabled={isLocked}
                          className={`btn ${isActive ? "btn-primary" : "btn-secondary"}`}
                          style={{
                            textAlign: "left",
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            opacity: isLocked ? 0.6 : 1,
                          }}
                        >
                          <span>{challenge.title}</span>
                          <span
                            className={`badge ${isLocked ? "badge-warning" : "badge-info"}`}
                            style={{ textTransform: "capitalize" }}
                          >
                            {isLocked ? "locked" : status}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="flex-1 flex flex-col gap-6">
            <div className="card">
              {!showChallenges && (
                <div className="mb-4">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => setShowChallenges(true)}
                  >
                    Back to challenges
                  </button>
                </div>
              )}
              <h2 className="text-xl font-semibold mb-4">Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-lg font-semibold mb-1">
                    {activeCategory?.name || "Select a category"}
                  </h3>
                  <p
                    className="text-sm"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {activeCategory?.description ||
                      "Category details will appear here."}
                  </p>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-1">
                    {activeLevel
                      ? `Level ${activeLevel.levelNumber}: ${activeLevel.title}`
                      : "Select a level"}
                  </h3>
                  <p
                    className="text-sm"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {activeLevel?.description ||
                      "Level details will appear here."}
                  </p>
                  {activeLevel && (
                    <div className="mt-2">
                      <span
                        className={`badge ${getStatusBadge(progressMap[activeLevel._id] || "locked").className}`}
                      >
                        {
                          getStatusBadge(
                            progressMap[activeLevel._id] || "locked",
                          ).text
                        }
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-2">Challenge</h3>
                {!activeChallenge ? (
                  <p
                    className="text-sm"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    Select a challenge to see full details.
                  </p>
                ) : (
                  <>
                    <h4 className="text-md font-semibold mb-2">
                      {activeChallenge.title}
                    </h4>
                    {activeChallenge.description && (
                      <p className="text-sm text-secondary mb-3">
                        {activeChallenge.description}
                      </p>
                    )}
                    {activeChallenge.requirements?.length > 0 && (
                      <div className="mb-3">
                        <h4 className="font-semibold mb-1">Requirements</h4>
                        <ul className="pl-5 text-sm text-secondary">
                          {activeChallenge.requirements.map((item) => (
                            <li key={item}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {activeChallenge.resources?.length > 0 && (
                      <div className="mb-3">
                        <h4 className="font-semibold mb-1">Resources</h4>
                        <ul className="pl-5 text-sm text-secondary">
                          {activeChallenge.resources.map((item) => (
                            <li key={item}>{item}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {activeChallenge.tags?.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {activeChallenge.tags.map((tag) => (
                          <span key={tag} className="badge badge-info">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>

            <div className="card">
              <h2 className="text-xl font-semibold mb-4">Submit Your Work</h2>
              {!activeChallengeId ? (
                <p
                  className="text-sm"
                  style={{ color: "var(--text-secondary)" }}
                >
                  Select a challenge to submit your work.
                </p>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                  {submitError && (
                    <div className="alert alert-error">{submitError}</div>
                  )}
                  {submitSuccess && (
                    <div className="alert alert-success">{submitSuccess}</div>
                  )}
                  {(() => {
                    const existing =
                      getSubmissionForChallenge(activeChallengeId);
                    if (existing?.status === "approved") {
                      return (
                        <div className="alert alert-info">
                          This submission has been approved and can’t be edited.
                        </div>
                      );
                    }
                    return null;
                  })()}

                  <label className="flex flex-col gap-2">
                    <span className="font-semibold">Repo URL</span>
                    <input
                      type="url"
                      value={repoUrl}
                      onChange={(e) => setRepoUrl(e.target.value)}
                      placeholder="https://github.com/yourname/project"
                      required
                      disabled={
                        actionLoading ||
                        getSubmissionForChallenge(activeChallengeId)?.status ===
                          "approved"
                      }
                      className="form-input"
                    />
                  </label>
                  <label className="flex flex-col gap-2">
                    <span className="font-semibold">Demo URL (optional)</span>
                    <input
                      type="url"
                      value={demoUrl}
                      onChange={(e) => setDemoUrl(e.target.value)}
                      placeholder="https://your-demo.com"
                      disabled={
                        actionLoading ||
                        getSubmissionForChallenge(activeChallengeId)?.status ===
                          "approved"
                      }
                      className="form-input"
                    />
                  </label>
                  <label className="flex flex-col gap-2">
                    <span className="font-semibold">Notes (optional)</span>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={4}
                      disabled={
                        actionLoading ||
                        getSubmissionForChallenge(activeChallengeId)?.status ===
                          "approved"
                      }
                      className="form-textarea"
                    />
                  </label>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={
                      actionLoading ||
                      getSubmissionForChallenge(activeChallengeId)?.status ===
                        "approved"
                    }
                  >
                    {actionLoading ? "Submitting..." : "Submit"}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Milestones;
