import React from "react";

const MilestoneSidebar = ({
  categories,
  activeCategoryId,
  onSelectCategory,
  levels,
  activeLevelId,
  onSelectLevel,
  levelProgressMap,
  activeChallengeId,
  showChangeChallenge,
  onChangeChallenge,
  loading,
  className,
  onClose,
}) => {
  const getStatusBadge = (status) => {
    if (status === "completed")
      return { className: "badge-success", text: "Completed" };
    if (status === "unlocked")
      return { className: "badge-info", text: "In Progress" };
    return { className: "badge-warning", text: "Not Started" };
  };

  return (
    <div className={className || "w-full lg:w-72 flex flex-col gap-4"}>
      {onClose && (
        <div className="flex justify-end mb-2 lg:hidden">
          <button onClick={onClose} className="btn btn-outline">
            Close
          </button>
        </div>
      )}

      {activeChallengeId && showChangeChallenge && onChangeChallenge && (
        <div className="mb-2">
          <button
            type="button"
            onClick={onChangeChallenge}
            className="btn btn-secondary w-full"
          >
            Change challenge
          </button>
        </div>
      )}

      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Categories</h2>
        <div className="flex flex-col gap-2">
          {categories.map((category) => (
            <button
              key={category._id}
              className={`btn ${activeCategoryId === category._id ? "btn-primary" : "btn-secondary"}`}
              onClick={() => onSelectCategory(category._id)}
              style={{ textAlign: "left" }}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Levels</h2>
        {loading ? (
          <div className="loading">Loading...</div>
        ) : levels.length === 0 ? (
          <p style={{ color: "var(--text-secondary)" }}>
            No levels available yet.
          </p>
        ) : (
          <div className="flex flex-col gap-2">
            {levels.map((level) => {
              const status = levelProgressMap[level._id] || "locked";
              const badge = getStatusBadge(status);
              const isActive = activeLevelId === level._id;
              return (
                <button
                  key={level._id}
                  type="button"
                  onClick={() => onSelectLevel(level._id)}
                  className={`btn ${isActive ? "btn-primary" : "btn-secondary"}`}
                  style={{
                    textAlign: "left",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <span>
                    Level {level.levelNumber}: {level.title}
                  </span>
                  <span className={`badge ${badge.className}`}>
                    {badge.text}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default MilestoneSidebar;
